# Simple TODO

## Description

本应用修改自一个简单的python示例: [simple-todo: 一个简易的 todo 程序 - web.py 中文教程](http://simple-is-better.com/news/309)

## Install

    $ npm install express ejs mysql
    
## Run
    
    $ node todo/server.js
    
## Demo

[http://s8.hk:3888](http://s8.hk:3888)